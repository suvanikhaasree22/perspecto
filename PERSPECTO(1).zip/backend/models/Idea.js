const mongoose=require('mongoose');
const ideaSchema=new mongoose.Schema({author:{type:mongoose.Schema.Types.ObjectId,ref:'User'},title:{type:String,required:true},description:String,status:{type:String,enum:['Idea','Discuss','Build','Completed'],default:'Idea'},suggestions:[{type:mongoose.Schema.Types.ObjectId,ref:'IdeaContribution'}]},{timestamps:true});
module.exports=mongoose.model('Idea',ideaSchema);
