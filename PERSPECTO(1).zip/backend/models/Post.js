const mongoose=require('mongoose');
const postSchema=new mongoose.Schema({
 author:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},title:{type:String,required:true,trim:true},content:{type:String,required:true},excerpt:{type:String},coverImage:{type:String,default:''},category:{type:String,default:'Personal'},mood:{type:String,default:'Curious'},type:{type:String,enum:['Blog','Discussion','Idea','Time Capsule'],default:'Blog'},tags:[String],views:{type:Number,default:0},likes:[{type:mongoose.Schema.Types.ObjectId,ref:'User'}],bookmarks:[{type:mongoose.Schema.Types.ObjectId,ref:'User'}],perspectives:{agree:{type:Number,default:0},different:{type:Number,default:0},question:{type:Number,default:0},challenge:{type:Number,default:0}},published:{type:Boolean,default:true}
},{timestamps:true});
postSchema.virtual('readingTime').get(function(){return Math.max(1,Math.ceil(this.content.split(/\s+/).length/200));});
postSchema.set('toJSON',{virtuals:true});
module.exports=mongoose.model('Post',postSchema);
