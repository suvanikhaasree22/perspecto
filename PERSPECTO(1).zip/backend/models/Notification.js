const mongoose=require('mongoose');
module.exports=mongoose.model('Notification',new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},actor:{type:mongoose.Schema.Types.ObjectId,ref:'User'},type:String,message:String,read:{type:Boolean,default:false},link:String},{timestamps:true}));
