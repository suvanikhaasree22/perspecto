const mongoose=require('mongoose');
module.exports=mongoose.model('Follow',new mongoose.Schema({follower:{type:mongoose.Schema.Types.ObjectId,ref:'User'},following:{type:mongoose.Schema.Types.ObjectId,ref:'User'}},{timestamps:true}));
