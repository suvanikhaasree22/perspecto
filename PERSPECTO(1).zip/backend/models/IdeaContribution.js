const mongoose=require('mongoose');
module.exports=mongoose.model('IdeaContribution',new mongoose.Schema({idea:{type:mongoose.Schema.Types.ObjectId,ref:'Idea'},author:{type:mongoose.Schema.Types.ObjectId,ref:'User'},content:{type:String,required:true}},{timestamps:true}));
