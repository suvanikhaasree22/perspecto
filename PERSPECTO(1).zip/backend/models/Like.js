const mongoose=require('mongoose');
module.exports=mongoose.model('Like',new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},post:{type:mongoose.Schema.Types.ObjectId,ref:'Post'}},{timestamps:true}));
