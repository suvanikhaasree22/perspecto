const mongoose=require('mongoose');
module.exports=mongoose.model('TimeCapsule',new mongoose.Schema({author:{type:mongoose.Schema.Types.ObjectId,ref:'User'},title:String,content:String,coverImage:String,unlockAt:{type:Date,required:true}},{timestamps:true}));
