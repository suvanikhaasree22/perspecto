const mongoose=require('mongoose');
module.exports=mongoose.model('Evidence',new mongoose.Schema({claim:{type:mongoose.Schema.Types.ObjectId,ref:'FactClaim'},author:{type:mongoose.Schema.Types.ObjectId,ref:'User'},url:String,note:String},{timestamps:true}));
