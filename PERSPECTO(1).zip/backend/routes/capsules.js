const router=require('express').Router();const Capsule=require('../models/TimeCapsule');const {protect}=require('../middleware/auth');
router.get('/mine',protect,async(req,res,next)=>{try{res.json(await Capsule.find({author:req.user._id}).sort('unlockAt'))}catch(e){next(e)}});
router.post('/',protect,async(req,res,next)=>{try{const {title,content,coverImage,unlockAt}=req.body;if(new Date(unlockAt)<=new Date())return res.status(400).json({message:'Unlock date must be in the future'});const c=await Capsule.create({author:req.user._id,title,content,coverImage,unlockAt});res.status(201).json(c)}catch(e){next(e)}});
router.get('/:id',protect,async(req,res,next)=>{try{const c=await Capsule.findOne({_id:req.params.id,author:req.user._id});if(!c)return res.status(404).json({message:'Capsule not found'});if(new Date(c.unlockAt)>new Date())return res.json({...c.toObject(),locked:true,content:undefined});res.json({...c.toObject(),locked:false})}catch(e){next(e)}});
module.exports=router;
