const router=require('express').Router();const Idea=require('../models/Idea');const IdeaContribution=require('../models/IdeaContribution');const {protect}=require('../middleware/auth');
router.get('/',async(req,res,next)=>{try{res.json(await Idea.find().populate('author','name avatar').sort('-createdAt').limit(30))}catch(e){next(e)}});
router.post('/',protect,async(req,res,next)=>{try{const i=await Idea.create({author:req.user._id,title:req.body.title,description:req.body.description,status:req.body.status||'Idea'});res.status(201).json(await i.populate('author','name avatar'))}catch(e){next(e)}});
router.post('/:id/contributions',protect,async(req,res,next)=>{try{const c=await IdeaContribution.create({idea:req.params.id,author:req.user._id,content:req.body.content});await Idea.findByIdAndUpdate(req.params.id,{$push:{suggestions:c._id}});res.status(201).json(await c.populate('author','name avatar'))}catch(e){next(e)}});
router.get('/:id/contributions',async(req,res,next)=>{try{res.json(await IdeaContribution.find({idea:req.params.id}).populate('author','name avatar').sort('-createdAt'))}catch(e){next(e)}});
module.exports=router;
